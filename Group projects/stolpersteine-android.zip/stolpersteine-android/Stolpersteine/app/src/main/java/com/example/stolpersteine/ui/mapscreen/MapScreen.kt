package com.example.stolpersteine.ui.mapscreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.location.Location
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.example.stolpersteine.R
import com.example.stolpersteine.ui.LocationUtils
import com.example.stolpersteine.ui.theme.DarkGold
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.google.maps.android.compose.CameraPositionState
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.MapsComposeExperimentalApi
import com.google.maps.android.compose.clustering.Clustering
import com.google.maps.android.compose.rememberCameraPositionState
import java.lang.reflect.Type
import java.nio.charset.Charset


fun fetchStones(context: Context){
    val gson = Gson()
    val eindhovenData = context.resources.openRawResource(R.raw.eindhovenstones).bufferedReader(Charset.defaultCharset()).use { it.readText() }
    val listType: Type = object : TypeToken<List<Stolperstein>>() {}.type
    val stolpersteines: List<Stolperstein> = gson.fromJson(eindhovenData, listType)
    println(stolpersteines)
}

fun bitmapDescriptorFromVector(context: Context, vectorResId: Int): BitmapDescriptor {
    val vectorDrawable = ContextCompat.getDrawable(context, vectorResId)
    vectorDrawable?.setBounds(0, 0, vectorDrawable.intrinsicWidth, vectorDrawable.intrinsicHeight)
    val bitmap = Bitmap.createBitmap(vectorDrawable!!.intrinsicWidth, vectorDrawable.intrinsicHeight, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    vectorDrawable.draw(canvas)
    return BitmapDescriptorFactory.fromBitmap(bitmap)
}


@Composable
fun MapScreen(navController: NavController, fusedLocationProviderClient: FusedLocationProviderClient, stolpersteines: List<Stolperstein>){
    val context = LocalContext.current
    fetchStones(context)
    var currentLocation by remember { mutableStateOf(LocationUtils.getDefaultLocation()) }

    val cameraPositionState = rememberCameraPositionState()
    cameraPositionState.position = CameraPosition.fromLatLngZoom(
        LocationUtils.getPosition(currentLocation), 12f)

    var requestLocationUpdate by remember { mutableStateOf(true)}

    MyGoogleMap(
        stolpersteines,
        currentLocation,
        cameraPositionState,
        onGpsIconClick = {
            requestLocationUpdate = true
        }
    )

    if(requestLocationUpdate) {
        LocationPermissionsAndSettingDialogs(
            updateCurrentLocation = {
                requestLocationUpdate = false
                LocationUtils.requestLocationResultCallback(fusedLocationProviderClient) { locationResult ->

                    locationResult.lastLocation?.let { location ->
                        currentLocation = location
                    }

                }
            }
        )
    }
}

@OptIn(MapsComposeExperimentalApi::class)
@Composable
private fun MyGoogleMap(stolpersteines: List<Stolperstein>, currentLocation: Location, cameraPositionState: CameraPositionState, onGpsIconClick: () -> Unit) {
    val context = LocalContext.current

    val mapProperties = MapProperties(
        isBuildingEnabled = false,
        isIndoorEnabled = false,
        isTrafficEnabled = false,
        mapType = MapType.TERRAIN,
        maxZoomPreference = 21f,
        minZoomPreference = 1f,
    )

    val mapUiSettings by remember {
        mutableStateOf(
            MapUiSettings(
                compassEnabled = true,
                myLocationButtonEnabled = true,
                rotationGesturesEnabled = true,
                scrollGesturesEnabled = true,
                scrollGesturesEnabledDuringRotateOrZoom = true,
                tiltGesturesEnabled = true,
                zoomControlsEnabled = false,
                zoomGesturesEnabled = true,
            )
        )
    }

    GoogleMap(
        modifier = Modifier.fillMaxSize(),
        cameraPositionState = cameraPositionState,
        properties = mapProperties,
        uiSettings = mapUiSettings,
    ){
        Clustering(
            items = stolpersteines,
            onClusterClick = {
                cameraPositionState.move(
                    CameraUpdateFactory.zoomIn()
                )
                false
            },
            onClusterItemClick = { _ ->
                false
            }
        )
    }
    GpsIconButton(onIconClick = onGpsIconClick)
}

class MapsComposeExperimentalApi {

}


@Composable
private fun GpsIconButton(onIconClick: () -> Unit) {

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Bottom,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {

            Button(onClick = onIconClick, Modifier.padding(bottom = 60.dp),
                colors = ButtonDefaults.outlinedButtonColors(containerColor =  Color(DarkGold.value), contentColor = Color.White)
            ) {
                Icon(
                    modifier = Modifier.zIndex(1f),
                    painter = painterResource(id = R.drawable.ic_gps_fixed),
                    contentDescription = null
                )
            }
        }
    }
}