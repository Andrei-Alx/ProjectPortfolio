package com.example.stolpersteine.ui.navbar

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.example.stolpersteine.R
import com.example.stolpersteine.ui.detailsscreen.DetailsScreen
import com.example.stolpersteine.ui.homescreen.HomeScreen
import com.example.stolpersteine.ui.mapscreen.MapScreen
import com.example.stolpersteine.ui.mapscreen.Stolperstein
import com.example.stolpersteine.ui.scanscreen.ScanScreen
import com.example.stolpersteine.ui.searchscreen.SearchScreen
import com.example.stolpersteine.ui.stonescreen.StoneScreen
import com.example.stolpersteine.ui.theme.BrightRed
import com.example.stolpersteine.ui.theme.DarkGold
import com.example.stolpersteine.ui.timeline.Timeline
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type
import java.nio.charset.Charset

fun printStones(context: Context): List<Stolperstein> {
    val gson = Gson()
    val eindhovenData = context.resources.openRawResource(R.raw.eindhovenstones).bufferedReader(
        Charset.defaultCharset()
    ).use { it.readText() }
    val listType: Type = object : TypeToken<List<Stolperstein>>() {}.type
    return gson.fromJson(eindhovenData, listType)
}

@Composable
fun Navigating(navController: NavHostController, fusedLocationProviderClient: FusedLocationProviderClient) {
    val context = LocalContext.current
    val stolpersteines: List<Stolperstein> = printStones(context)
    NavHost(navController = navController, startDestination = "home"){
        composable("home"){
            HomeScreen(navController)
        }
        composable("map"){
            MapScreen(navController, fusedLocationProviderClient, stolpersteines)
        }
        composable("search"){
            SearchScreen(navController)

        }
        composable("detailsscreen/{id}", arguments = listOf(navArgument("my_param") { type = NavType.StringType }))
        {
            val param = it.arguments?.getString("id") ?: ""
            DetailsScreen(param = param)
        }
        composable("scan"){
            ScanScreen()
        }
        composable("stone"){
            StoneScreen(navController)
        }
        composable("timeline"){
            Timeline(navController)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NavBar(items: List<NavItem>, navController: NavController, modifier: Modifier, onItemClickListener: (NavItem)->Unit){
    val backStackEntry = navController.currentBackStackEntryAsState()
    BottomAppBar(modifier = modifier
        .drawBehind {
            val strokeWidth = 1.dp.toPx()
            val y = 0f
            drawLine(
                color = Color.White,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = strokeWidth
            )
        }
        .size(width = 600.dp, height = 50.dp),
        tonalElevation = 5.dp, containerColor = Color(DarkGold.value),)
    {
        items.forEach{item ->
            val selected = item.route == backStackEntry.value?.destination?.route
            NavigationBarItem(selected = selected, onClick = { onItemClickListener(item) }, alwaysShowLabel = true, icon = {
                Column (horizontalAlignment = Alignment.CenterHorizontally){
                    if(item.badgeCount > 0){
                        BadgedBox(badge = {
                            Text(text = item.badgeCount.toString())
                        }) {
                            Icon(imageVector = item.icon, contentDescription = item.name)
                            Text(text = item.name)
                        }
                    }else{
                        Icon(imageVector = item.icon, contentDescription = item.name)
                        Text(text = item.name)
                    }
                }
            }, colors = NavigationBarItemDefaults.colors (
                selectedIconColor = Color(BrightRed.value),
                unselectedIconColor = Color.White,
                indicatorColor = Color(DarkGold.value)
            ))
        }
    }
}