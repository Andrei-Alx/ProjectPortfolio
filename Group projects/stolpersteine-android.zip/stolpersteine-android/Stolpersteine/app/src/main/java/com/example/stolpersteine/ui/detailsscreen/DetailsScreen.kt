package com.example.stolpersteine.ui.detailsscreen

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

@Composable
fun DetailsScreen(param: String){
    Text(text = "DETAILS SCREEN", color = Color.Red, fontSize = 19.sp)
}