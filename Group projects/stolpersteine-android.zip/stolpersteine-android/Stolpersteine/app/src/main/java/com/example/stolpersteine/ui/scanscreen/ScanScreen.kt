package com.example.stolpersteine.ui.scanscreen

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

@Composable
fun ScanScreen() {
    Text(text = "SCAN SCREEN", color = Color.Red, fontSize = 19.sp)
}