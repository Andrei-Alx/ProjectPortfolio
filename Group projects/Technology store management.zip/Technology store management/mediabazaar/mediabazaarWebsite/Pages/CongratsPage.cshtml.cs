using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace mediabazaarWebsite.Pages
{
    public class CongratsPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
