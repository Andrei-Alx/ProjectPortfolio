﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// the simplest way to handle barcode input in C# WinForms https://stackoverflow.com/a/10850102
namespace Logic.ScannerLogic
{
    public class ScannerFunctionalitysHandler
    {
        public class JSONresponseFromAPI
        {
            public String status { get; set; }
            public String time { get; set; }
        }
       
    }
}
