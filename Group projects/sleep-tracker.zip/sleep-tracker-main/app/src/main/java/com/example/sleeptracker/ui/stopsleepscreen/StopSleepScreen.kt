package com.example.sleeptracker.ui.stopsleepscreen

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.sleeptracker.R

@Composable
fun StopSleepScreen(navController: NavController){

    @Composable
    fun CustomSlider(modifier: Modifier = Modifier, onSlideComplete: () -> Unit) {
        var targetValue by remember { mutableStateOf(0f) }
        var isSliding by remember { mutableStateOf(false) }
        val sliderPosition by animateFloatAsState(
            label = "",
            targetValue = targetValue,
            animationSpec = if (isSliding) {
                spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
            } else {
                tween(durationMillis = 1000)
            }
        )

        Box(modifier = modifier.fillMaxWidth()) {
            Slider(
                value = sliderPosition,
                onValueChange = { newValue ->
                    isSliding = true
                    targetValue = newValue
                    if (newValue >= 1f) {
                        onSlideComplete()
                    }
                },
                modifier = Modifier
                    .align(Alignment.Center)
                    .height(50.dp)
                    .padding(horizontal = 100.dp),
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.White,
                    inactiveTrackColor = Color.Gray
                ),
                valueRange = 0f..1f,
                steps = 0,
                onValueChangeFinished = {
                    isSliding = false
                    if (targetValue >= 1f) {
                        targetValue = 0f
                    }
                }
            )
        }
    }



    Column(verticalArrangement = Arrangement.Center) {
        Image(painterResource(id = R.drawable.sleep), contentDescription = "Face emoji", modifier = Modifier.size(100.dp).offset(x= (150).dp, y=430.dp)) }
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(start = 0.dp, top = 580.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        CustomSlider(onSlideComplete = { navController.navigate("sleepquestions") })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text(text = "Swipe to stop tracking", color = Color.White, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold), fontSize = 19.sp)
            Icon(imageVector = Icons.Filled.ArrowForward, contentDescription = "Swipe Arrow", modifier = Modifier.size(30.dp), tint = Color.White)
        }
    }
}