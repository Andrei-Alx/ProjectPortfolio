package com.example.sleeptracker.ui.sleepdetails

import java.time.LocalTime

data class SleepDetails(
    val hoursAwake: UInt,
    val minutesAwake: UInt,
    val hoursRem: UInt,
    val minutesRem: UInt,
    val hoursLight: UInt,
    val minutesLight: UInt,
    val hoursDeep: UInt,
    val minutesDeep: UInt,
    val wentToSleepTime: LocalTime,
    val wakeUpTime: LocalTime,
    val hoursSlept: UInt,
    val minutesSlept: UInt,
    val ratingEmoji: Int,
    var tips: String
)
