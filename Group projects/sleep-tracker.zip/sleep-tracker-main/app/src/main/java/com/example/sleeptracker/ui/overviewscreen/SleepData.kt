package com.example.sleeptracker.ui.overviewscreen

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

data class SleepData(
    val id: UInt,
    val dayOfWeek: DayOfWeek,
    val date: LocalDate,
    val wentToSleepTime: LocalTime,
    val wakeUpTime: LocalTime,
    val hoursSlept: UInt,
    val minutesSlept: UInt,
    val ratingEmoji: Int
)
