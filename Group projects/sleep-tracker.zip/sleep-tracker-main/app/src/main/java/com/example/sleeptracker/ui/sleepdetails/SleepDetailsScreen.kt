package com.example.sleeptracker.ui.sleepdetails

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.rememberNavController
import com.example.sleeptracker.R
import java.time.LocalTime

@Composable
fun SleepDetailsScreen(param: String){
    val navController = rememberNavController()
    val sleepDetails = listOf(
        SleepDetails(
            hoursAwake = 0u,
            minutesAwake = 3u,
            hoursRem = 2u,
            minutesRem = 13u,
            hoursLight = 3u,
            minutesLight = 7u,
            hoursDeep = 2u,
            minutesDeep = 0u,
            wentToSleepTime = LocalTime.of(23, 30),
            wakeUpTime = LocalTime.of(7, 53),
            hoursSlept = 7u,
            minutesSlept = 23u,
            ratingEmoji = R.drawable.veryhappy,
            tips = ""
        ),
        SleepDetails(
            hoursAwake = 0u,
            minutesAwake = 10u,
            hoursRem = 1u,
            minutesRem = 45u,
            hoursLight = 2u,
            minutesLight = 45u,
            hoursDeep = 1u,
            minutesDeep = 20u,
            wentToSleepTime = LocalTime.of(0, 30),
            wakeUpTime = LocalTime.of(6, 30),
            hoursSlept = 6u,
            minutesSlept = 0u,
            ratingEmoji = R.drawable.bad,
            tips = ""
        ),
        SleepDetails(
            hoursAwake = 0u,
            minutesAwake = 20u,
            hoursRem = 3u,
            minutesRem = 10u,
            hoursLight = 3u,
            minutesLight = 15u,
            hoursDeep = 1u,
            minutesDeep = 15u,
            wentToSleepTime = LocalTime.of(23, 15),
            wakeUpTime = LocalTime.of(7, 15),
            hoursSlept = 8u,
            minutesSlept = 0u,
            ratingEmoji = R.drawable.neutral,
            tips = ""
        )
    )

    @Composable
    fun SleepStageComponent(stageName: String, hours: UInt, minutes: UInt, color: Color) {
        Row {
            Text(text = "$stageName: ", modifier = Modifier.width(55.dp), color = Color.White)
            LinearProgressIndicator(progress = (hours.toFloat() * 200 + minutes.toFloat()) / (24 * 60),
                trackColor = Color.White,
                color = color,
                modifier = Modifier.height(30.dp).width(150.dp))
            Text(text = "$hours hours $minutes minutes", color = Color.White)
        }
    }

    @Composable
    fun DetailsCard(){
        val sleepInfo = sleepDetails[param.toInt()]
        if(sleepInfo.wentToSleepTime.hour > 22){
            sleepInfo.tips = "Aim for an earlier bedtime!"
        }else if(sleepInfo.wakeUpTime.hour <= 5){
            sleepInfo.tips = "Try waking up later!"
        }else if(sleepInfo.hoursSlept <= 6u){
            sleepInfo.tips = "You should sleep more!"
        }else{
            sleepInfo.tips = "Your sleep stats are looking good!"
        }
        Column(modifier=Modifier.padding(15.dp)) {
            Image(painterResource(id = sleepInfo.ratingEmoji), contentDescription = "Face emoji", modifier = Modifier.size(70.dp).align(CenterHorizontally))
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "You slept from ${sleepInfo.wentToSleepTime} to ${sleepInfo.wakeUpTime}", color = Color.White, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold), fontSize = 20.sp)
            Text(text = "Total: ${sleepInfo.hoursSlept} h ${sleepInfo.minutesSlept} m", color = Color.White, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(16.dp))
            SleepStageComponent("Awake", sleepInfo.hoursAwake, sleepInfo.minutesAwake, Color(
                247,
                101,
                131,
                255
            )
            )
            Spacer(modifier = Modifier.height(16.dp))
            SleepStageComponent("REM", sleepInfo.hoursRem, sleepInfo.minutesRem, Color(149,92,180))
            Spacer(modifier = Modifier.height(16.dp))
            SleepStageComponent("Light", sleepInfo.hoursLight, sleepInfo.minutesLight, Color(43,93,160))
            Spacer(modifier = Modifier.height(16.dp))
            SleepStageComponent("Deep", sleepInfo.hoursDeep, sleepInfo.minutesDeep, Color(8,21,78))
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Tips: ${sleepInfo.tips}", color = Color.White)
        }
    }
    DetailsCard()

}