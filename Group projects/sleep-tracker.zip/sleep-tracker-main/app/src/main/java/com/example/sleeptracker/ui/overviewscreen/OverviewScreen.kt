package com.example.sleeptracker.ui.overviewscreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.sleeptracker.R
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun OverviewScreen(onNavigateToDetails: (String) -> Unit){
    val navController = rememberNavController()
    val sleepSessions = listOf(
        SleepData(
            id = 0u,
            dayOfWeek = DayOfWeek.TUESDAY,
            date = LocalDate.of(2023, 9, 26),
            wentToSleepTime = LocalTime.of(23, 30),
            wakeUpTime = LocalTime.of(7, 53),
            hoursSlept = 7u,
            minutesSlept = 23u,
            ratingEmoji = R.drawable.veryhappy
        ),
        SleepData(
            id = 1u,
            dayOfWeek = DayOfWeek.WEDNESDAY,
            date = LocalDate.of(2023, 9, 27),
            wentToSleepTime = LocalTime.of(0, 30),
            wakeUpTime = LocalTime.of(6, 30),
            hoursSlept = 6u,
            minutesSlept = 0u,
            ratingEmoji = R.drawable.verybad
        ),
        SleepData(
            id = 2u,
            dayOfWeek = DayOfWeek.FRIDAY,
            date = LocalDate.of(2023, 9, 29),
            wentToSleepTime = LocalTime.of(23, 15),
            wakeUpTime = LocalTime.of(7, 15),
            hoursSlept = 8u,
            minutesSlept = 0u,
            ratingEmoji = R.drawable.neutral
        ),
    )
    Text(
        text = "Overview",
        color = Color.Black,
        fontSize = 32.sp,
        modifier = Modifier.padding(top = 25.dp, start = 20.dp)
    )
    @Composable
    fun SleepCard(sleepSessions: List<SleepData>, navController: NavController) {
        Column(modifier = Modifier.verticalScroll(rememberScrollState(),enabled = true)) {
            sleepSessions.forEach { item ->
                Card(
                    modifier = Modifier.padding(8.dp).border(width = 3.dp, color = Color.White, shape = RoundedCornerShape(10)),
                    colors = CardDefaults.cardColors(containerColor = Color.Black)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.width(320.dp).weight(1f)){
                            Text(text = item.dayOfWeek.toString() + " " + item.date.toString(), color = Color.White, style = MaterialTheme.typography.displaySmall, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(text = item.wentToSleepTime.toString() + " - " + item.wakeUpTime.toString(), color = Color.White, style = MaterialTheme.typography.displaySmall, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(text = "${item.hoursSlept}hr ${item.minutesSlept}min", color = Color.White, style = MaterialTheme.typography.displaySmall, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(16.dp))
                            Button( onClick = { onNavigateToDetails(item.id.toString()) },modifier = Modifier.padding(0.dp,10.dp, 0.dp,0.dp), elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(119,121,159)))
                            {
                                Text("View details")
                            }
                        }
                            Image(painterResource(id = item.ratingEmoji), contentDescription = "Face emoji", modifier = Modifier.size(50.dp))
                    }
                }
            }
        }
    }
    SleepCard(sleepSessions, navController)
}