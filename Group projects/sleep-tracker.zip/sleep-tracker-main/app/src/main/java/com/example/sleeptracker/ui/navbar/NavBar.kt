package com.example.sleeptracker.ui.navbar

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.navArgument
import com.example.sleeptracker.ui.homescreen.HomeScreen
import com.example.sleeptracker.ui.infoscreen.InfoScreen
import com.example.sleeptracker.ui.overviewscreen.OverviewScreen
import com.example.sleeptracker.ui.profilescreen.PreviewSleepScheduleScreen
import com.example.sleeptracker.ui.sleepdetails.SleepDetailsScreen
import com.example.sleeptracker.ui.sleepquestionsscreen.SleepQuestionsScreen
import com.example.sleeptracker.ui.stopsleepscreen.StopSleepScreen

@Composable
fun Navigating(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "home"){
        composable("home"){
            HomeScreen(navController)
        }
        composable("tips"){
            InfoScreen()
        }
        composable("overview"){
            OverviewScreen(onNavigateToDetails = {
                navController.navigate("sleepdetails/$it")
            })
        }
        composable("sleepdetails/{id}", arguments = listOf(navArgument("my_param") { type = NavType.StringType }))
        {
            val param = it.arguments?.getString("id") ?: ""
            SleepDetailsScreen(param = param)
        }
        composable("profile"){
            PreviewSleepScheduleScreen(navController)
        }
        composable("stopsleep"){
            StopSleepScreen(navController)
        }
        composable("sleepquestions"){
            SleepQuestionsScreen(navController)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NavBar(items: List<NavItem>, navController: NavController, modifier: Modifier, onItemClickListener: (NavItem)->Unit){
    val backStackEntry = navController.currentBackStackEntryAsState()
    BottomAppBar(modifier = modifier.drawBehind {
        val strokeWidth = 5.dp.toPx()
        val y = 0f
        drawLine(color = Color.White, start = Offset(0f, y), end = Offset(size.width, y), strokeWidth = strokeWidth) }, tonalElevation = 5.dp, containerColor = Color.Black)
    {
        items.forEach{item ->
            val selected = item.route == backStackEntry.value?.destination?.route
            NavigationBarItem(selected = selected, onClick = { onItemClickListener(item) }, alwaysShowLabel = true, icon = {
                Column (horizontalAlignment = CenterHorizontally){
                    if(item.badgeCount > 0){
                        BadgedBox(badge = {
                            Text(text = item.badgeCount.toString())
                        }) {
                            Icon(imageVector = item.icon, contentDescription = item.name)
                            Text(text = item.name)
                        }
                    }else{
                        Icon(imageVector = item.icon, contentDescription = item.name)
                        Text(text = item.name)
                    }
                }
            }, colors = NavigationBarItemDefaults.colors (
                selectedIconColor = Color.Black,
                unselectedIconColor = Color.Gray,
                indicatorColor = Color.White
            ))
        }
    }
}