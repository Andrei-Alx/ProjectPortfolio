package com.example.sleeptracker.ui.infoscreen


import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sleeptracker.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "Tips & exercises",
                color = Color.White,
                fontSize = 32.sp,
                modifier = Modifier.padding(25.dp, 16.dp)
            )
            TopAppBar(
                modifier = Modifier.padding(24.dp, 16.dp).clip(shape = RoundedCornerShape(16.dp)),
                title = { Text(
                                text = "Search videos & articles") },
                actions = {
                    IconButton(onClick = { /* Handle search icon click */ }) {
                        Icon(Icons.Filled.Search, contentDescription = null)
                    }
                    IconButton(onClick = { /* Handle menu icon click */ }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = null)
                    }
                }
            )
        }
        item {
            EnvironmentSection()
        }
        // Add more sections as needed
    }
}

@Composable
fun EnvironmentSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Exercises before sleep",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                color = Color.White,
                modifier = Modifier.padding(12.dp, 12.dp)
            )
            TextButton(onClick = { /* Handle "See more" click */ }) {
                Text(
                    text = "See more",
                    color = Color.LightGray
                    )
            }
        }
        ScrollableImageGroup(imageResourceIds = imageResourceIds)
        Spacer(modifier = Modifier.height(16.dp))
        // Add the mock-up articles here
        SleepImprovementArticles()
    }
}

@Composable
fun ScrollableImageGroup(imageResourceIds: List<Int>) {
    LazyRow(
        modifier = Modifier
            .fillMaxSize()
            .height(200.dp) // Set the height of the scrollable row (increased height)
    ) {
        items(imageResourceIds) { imageResId ->
            Box(
                modifier = Modifier
                    .width(150.dp) // Set the width of each image (increased width)
                    .height(150.dp) // Set the height of each image (increased height)
                    .padding(8.dp) // Add padding between images
                    .clip(shape = RoundedCornerShape(16.dp)) // Apply rounded corners
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Bottom, // Align children at the bottom of the column
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = imageResId),
                        contentDescription = null,
                        contentScale = ContentScale.Crop, // Adjust the scaling of the images
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.8f) // Adjust image size within the column
                    )
                    Text(
                        text = "Meditate - 5min", // Replace this with your image description or label
                        color = Color.White,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SleepImprovementArticles() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.Start
    ) {
        // Mock-up articles
        Text(
            text = "Tips for Better Sleep",
            color = Color.White,
            fontSize = 18.sp
        )
        Text(
            text = "Learn about creating a sleep-conducive environment and bedtime routines.",
            color = Color.Gray
        )
        Text(
            text = "Meditation Techniques",
            color = Color.White,
            fontSize = 18.sp
        )
        Text(
            text = "Discover meditation exercises to calm your mind before bedtime.",
            color = Color.Gray
        )
        Text(
            text = "Stretching for Sleep",
            color = Color.White,
            fontSize = 18.sp
        )
        Text(
            text = "Explore gentle stretches to relax your body and prepare for sleep.",
            color = Color.Gray
        )
        // Add more articles as needed
    }
}



val imageResourceIds = listOf(
    R.drawable.meditation,
    R.drawable.sleeping,
    R.drawable.stretch
    // Add more image resource IDs as needed
)



