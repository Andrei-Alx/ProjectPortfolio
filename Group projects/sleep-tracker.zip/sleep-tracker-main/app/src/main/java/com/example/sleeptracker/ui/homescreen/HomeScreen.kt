package com.example.sleeptracker.ui.homescreen

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.sleeptracker.R

@Composable
fun HomeScreen(navController: NavController){
    @Composable
    fun StartSleepButton(navController: NavController) {
        val pulseAnim = remember { Animatable(1f) }

        LaunchedEffect(pulseAnim) {
            pulseAnim.animateTo(
                targetValue = 1.2f,
                animationSpec = infiniteRepeatable(
                    animation = tween(3000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(0.dp, 200.dp, 0.dp, 215.dp),
            contentAlignment = Alignment.Center
        ) {
            OutlinedButton(
                onClick = { navController.navigate("stopsleep") },
                modifier= Modifier.size(230.dp * pulseAnim.value),
                shape = CircleShape,
                border= BorderStroke(10.dp, Color.White),
                contentPadding = PaddingValues(0.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor =  Color.Magenta)
            ) {
                Text(text = "Start tracking sleep", color = Color.White, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold), fontSize = 18.sp)
            }
        }
    }

    @Composable
    fun DisplayCard(value: String, image: Int) {
        Card(
            modifier = Modifier
                .padding(5.dp)
                .width(185.dp)
                .height(150.dp),
            elevation = CardDefaults.cardElevation(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black, contentColor = Color.White),
            border= BorderStroke(2.dp, Color.White),
        ) {
            Column(
                modifier = Modifier.padding(15.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(painterResource(id = image), contentDescription = "Face emoji", modifier = Modifier.size(50.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = value, style = MaterialTheme.typography.displayMedium, fontSize = 17.sp)
            }
        }
    }

    @Composable
    fun ViewDisplayCard() {
        Row {
            DisplayCard(value = "Last night: 7h 23m", image = R.drawable.sleep)
            DisplayCard(value = "Average: 60 bpm", image = R.drawable.heartrate)
        }
    }

    @Composable
    fun ViewRecentTip() {
        Box(
            modifier = Modifier
                .padding(16.dp),
        ) {
            Text(
                text = "Tip: Aim for an earlier bedtime",
                style = MaterialTheme.typography.headlineSmall.copy(color = Color.White),
                modifier = Modifier.padding(top = 600.dp),
                fontSize = 22.sp
            )
            Text(
                text = "See more tips",
                style = MaterialTheme.typography.displayMedium.copy(color = Color.LightGray, textDecoration = TextDecoration.Underline),
                modifier = Modifier
                    .offset(x= (-90).dp, y=30.dp)
                    .clickable { navController.navigate("tips") }
                    .align(Alignment.BottomCenter),
                fontSize = 17.sp
            )
        }
    }

    ViewDisplayCard()
    StartSleepButton(navController)
    ViewRecentTip()
}