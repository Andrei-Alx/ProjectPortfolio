package com.example.sleeptracker

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.rememberNavController
import com.example.sleeptracker.ui.navbar.NavBar
import com.example.sleeptracker.ui.navbar.NavItem
import com.example.sleeptracker.ui.navbar.Navigating
import com.example.sleeptracker.ui.theme.SleepTrackerTheme

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SleepTrackerTheme {
                val navController = rememberNavController()
                Scaffold (bottomBar = {
                    NavBar(items = listOf(
                        NavItem(
                            name = "Home",
                            route = "home",
                            icon = Icons.Default.Home
                        ),
                        NavItem(
                            name = "Tips",
                            route = "tips",
                            icon = Icons.Default.Info
                        ),
                        NavItem(
                            name = "Sleep",
                            route = "overview",
                            icon = Icons.Default.Share
                        ),
                        NavItem(
                            name = "Schedule",
                            route = "profile",
                            icon = Icons.Default.Settings
                        ),
                    ), navController = navController, modifier = Modifier, onItemClickListener = {navController.navigate(it.route)} )
                }, containerColor = Color.Black){
                    Navigating(navController = navController)
                }
            }
        }
    }
}