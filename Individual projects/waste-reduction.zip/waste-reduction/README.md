# Waste reduction

First open your terminal and clone this repository:

```shell
git clone https://git.fhict.nl/I491992/waste-reduction.git

cd waste-reduction

cd WeLeafWaste
```
## Name
Duocase 23 Waste Reduction.

## Link
https://i491992.hera.fhict.nl/

## Description
For this Duocase we made an app that scans products and says what material it is made of.

## Project status
Complete.

## Code status
Complete. The code works fine on the browser, only on some phones the camera doesn't work. That is something for a future iteration to take a look at.

### Made by:
Made by Andrei Alexandru and Thimo van der Vlies
