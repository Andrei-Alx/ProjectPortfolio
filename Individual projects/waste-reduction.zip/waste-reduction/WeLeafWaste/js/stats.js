// Function to update the statistics on the page
function updateStatistics() {
    // Update the total scanned items count
    document.querySelector(".total-scanned-data").innerText = getTotalScannedItems();

    // Update each sub-category count
    updateSubCategory("Battery");
    updateSubCategory("Paper");
    updateSubCategory("Plastic");
    updateSubCategory("Metal");
    updateSubCategory("Clothes");
    updateSubCategory("Biological");

    // Check conditions and update advice text
    updateAdviceText();
}

// Function to get the total scanned items count
function getTotalScannedItems() {
    let total = 0;
    // Loop through each item in localStorage and sum up the counts
    for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key) && key !== "predictionResult" && key !== "bin") {
            total += parseInt(localStorage.getItem(key)) || 0;
        }
    }
    return total;
}

// Function to update a specific sub-category count
function updateSubCategory(subCategory) {
    let count = parseInt(localStorage.getItem(subCategory)) || 0;
    // Update the corresponding element on the page
    document.querySelector(`#${subCategory}`).innerText = count;
}

// Function to update advice text based on conditions and sub-category counts
function updateAdviceText() {
    let infoAdviceElement = document.getElementById("info-advice");
    let plasticCount = parseInt(localStorage.getItem("Plastic")) || 0;
    let batteryCount = parseInt(localStorage.getItem("Battery")) || 0;
    let paperCount = parseInt(localStorage.getItem("Paper")) || 0;
    let metalCount = parseInt(localStorage.getItem("Metal")) || 0;
    let textileCount = parseInt(localStorage.getItem("Clothes")) || 0;
    let gftCount = parseInt(localStorage.getItem("Biological")) || 0;

    // Example condition: If the count of Plastic items is greater than a certain threshold
    if (plasticCount > 4) {
        infoAdviceElement.innerText = "You've scanned a lot of plastic items! Consider reducing plastic usage.";
    } else if (batteryCount > 3) {
        infoAdviceElement.innerText = "You've scanned a lot of battery items! Consider reducing battery usage.";
    } else if (paperCount > 4) {
        infoAdviceElement.innerText = "You've scanned a lot of paper items! Consider reducing paper usage.";
    } else if (metalCount > 2) {
        infoAdviceElement.innerText = "You've scanned a lot of metal items! Consider reducing metal usage.";
    } else if (textileCount > 2) {
        infoAdviceElement.innerText = "You've scanned a lot of textile items! Consider reducing textile usage.";
    } else if (gftCount > 5) {
        infoAdviceElement.innerText = "You've scanned a lot of GFT items! Consider reducing GFT usage.";
    } else {
        // Reset the advice text to a default message or leave it unchanged
        infoAdviceElement.innerText = "For more information, click on the button below.";
    }
}


// Call the updateStatistics function when the page loads
updateStatistics();
