function updateStatistics() {
    // Update the total scanned items count
    document.querySelector(".section-number-total").innerText = getTotalScannedItems();

    // Update each sub-category count
    updateSubCategory("Plastic");
}

// Function to get the total scanned items count
function getTotalScannedItems() {
    let total = 0;
    // Loop through each item in localStorage and sum up the counts
    for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key) && key !== "predictionResult" && key !== "bin") {
            total += parseInt(localStorage.getItem(key)) || 0;
        }
    }
    return total;
}

function updateSubCategory(subCategory) {
    let count = localStorage.getItem(subCategory) || 0;
    console.log(`Updating ${subCategory} count to ${count}`);
    // Update the corresponding element on the page
    document.querySelector(`#${subCategory}`).innerText = count;
}


// Call the updateStatistics function when the page loads
updateStatistics();