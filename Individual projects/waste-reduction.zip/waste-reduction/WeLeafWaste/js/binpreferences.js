function savePreferences() {
    const checkboxes = document.querySelectorAll('.q2-text1 input[type="checkbox"]:checked');

    const selectedBins = [...checkboxes].map(function (checkbox) {
        return checkbox.dataset.bintype
    });

    console.log(selectedBins)

    localStorage.setItem('selectedBins', JSON.stringify(selectedBins));

    window.location.href = 'onboard2.html';
}

function saveSettings() {
    const checkboxes = document.querySelectorAll('.q2-text1 input[type="checkbox"]:checked');

    const selectedBins = [...checkboxes].map(function (checkbox) {
        return checkbox.dataset.bintype
    });

    console.log(selectedBins)

    localStorage.setItem('selectedBins', JSON.stringify(selectedBins));
}
