const URL = "https://teachablemachine.withgoogle.com/models/aM4mTowT2/";

let model, webcam, labelContainer, maxPredictions;

async function init() {
    const modelURL = URL + "model.json";
    const metadataURL = URL + "metadata.json";

    model = await tmImage.load(modelURL, metadataURL);
    maxPredictions = model.getTotalClasses();

    const flip = true;
    webcam = new tmImage.Webcam(200, 200, flip);
    await webcam.setup();
    await webcam.play();
    window.requestAnimationFrame(loop);

    document.getElementById("webcam-container").appendChild(webcam.canvas);
    labelContainer = document.getElementById("label-container");
    for (let i = 0; i < maxPredictions; i++) {
        labelContainer.appendChild(document.createElement("div"));
    }
}

async function loop() {
    webcam.update();
    await predict(webcam.canvas);
    window.requestAnimationFrame(loop);
}

async function predict(imageElement) {
    const prediction = await model.predict(imageElement);
    let highestProbabilityIndex = 0;
    let highestProbability = prediction[0].probability;
    for (let i = 1; i < maxPredictions; i++) {
        if (prediction[i].probability > highestProbability) {
            highestProbability = prediction[i].probability;
            highestProbabilityIndex = i;
        }
    }

    for (let i = 0; i < maxPredictions; i++) {
        labelContainer.childNodes[i].innerHTML = "";
    }

    const classPrediction = prediction[highestProbabilityIndex].className + " " + Math.round(prediction[highestProbabilityIndex].probability * 100) + "%";
    labelContainer.childNodes[highestProbabilityIndex].innerHTML = classPrediction;

    const firstWord = classPrediction.split(' ')[0];
    var correctBin;
    if(firstWord === "Plastic"){
        correctBin = "Plastic bin"
    } else if(firstWord === "Metal") {
        correctBin = "General waste bin"
    } else if(firstWord === "Glass") {
        correctBin = "General waste bin"
    } else if(firstWord === "Battery") {
        correctBin = "General waste bin"
    } else if(firstWord === "Biological") {
        correctBin = "Green waste bin"
    } else if(firstWord === "Cardboard") {
        correctBin = "Paper & Cardboard bin"
    } else if(firstWord === "Clothes") {
        correctBin = "Please find a special textiles bin."
    } else if(firstWord === "Paper") {
        correctBin = "Paper & Cardboard bin"
    } else if(firstWord === "Shoes") {
        correctBin = "Please find a special textiles bin. Yes, that is correct, shoes and clothes are recycled together!"
    } else {
        correctBin = "General waste bin"
    }

    localStorage.setItem('predictionResult', firstWord);
    localStorage.setItem('bin', correctBin);
}


function capture() {
    webcam.stop();

    const canvas = document.createElement('canvas');
    canvas.classList.add('picture')
    canvas.width = webcam.canvas.width;
    canvas.height = webcam.canvas.height;
    canvas.getContext('2d').drawImage(webcam.canvas, 0, 0);

    const webcamContainer = document.getElementById("webcam-container");
    webcamContainer.removeChild(webcam.canvas);
    webcamContainer.appendChild(canvas);

    predict(canvas);
}
