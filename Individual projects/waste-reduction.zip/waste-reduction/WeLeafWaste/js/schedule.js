const labels = JSON.parse(localStorage.getItem('selectedBins'));

const cardsContainer = document.getElementById('cards');

cardsContainer.innerHTML = '';

labels.forEach(function (label) {
    const card = document.createElement('div');

    card.className = 'collection';

console.log(label)

    if (label === 'General waste') {
        card.innerHTML = '<img src="public/images/graybin.png" style="margin-left: 20px;"><p style="font-weight: bold; margin-left: 30px;"><strong>GRAY BIN</strong><br> General Waste</p> <p class="bin-text style="margin-right: 10px;">Today <br> <strong>9:00PM</strong></p>';
    }

    else if (label === 'Organic waste') {
        card.innerHTML = '<img src="public/images/greenbin.png" style="margin-left: 20px;"><p style="font-weight: bold; margin-left: 30px;">GREEN BIN <br> Organic waste</p> <p class="bin-text">Tuesday <br> <strong>11:00AM</strong></p>';
    }


    else if (label === 'Paper/Cardboard') {
        card.innerHTML = '<img src="public/images/bluebin.png" style="margin-left: 20px;"> <p style="font-weight: bold; margin-left: 30px; margin-right: 5px;">PAPER BIN <br> Paper & Cardboard</p> <p class="bin-text">Friday <br> <strong>9:30PM</strong></p>';
    }

    else if (label === 'General plastic') {
        card.innerHTML = '<img src="public/images/redbin.png" style="margin-left: 20px;"><p style="font-weight: bold; margin-left: 30px;">PLASTIC BIN <br> General plastic</p> <p class="bin-text">Thursday <br> <strong>7:00PM</strong></p>';
    }

    console.log(card)
    cardsContainer.appendChild(card);

    if (label !== labels[labels.length - 1]) {
        const hr = document.createElement('hr');
        hr.className = 'centered-line';
        cardsContainer.appendChild(hr);
    }
});
