function toggleCard(event) {
    var card = event.target.parentNode.parentNode;
    var arrow = event.target;
    if (card.classList.contains('collapsed')) {
        card.classList.remove('collapsed');
        arrow.classList.add('up');
    } else {
        card.classList.add('collapsed');
        arrow.classList.remove('up');
    }
}

window.onload = function() {
    var arrows = document.getElementsByClassName("arrow");
    for (var i = 0; i < arrows.length; i++) {
        arrows[i].addEventListener('click', toggleCard);
    }
}
